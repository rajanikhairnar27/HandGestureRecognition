---
applyTo: "tests/**/*.py"
---
- Use pytest, plain `assert`, fixed RNG seeds, no network access, no webcam.
- Test: feature invariance (rotation/scale/shift/mirror), cleaning behaviour, every gesture recognised
  (>= 90% on fresh samples), finger-state output, low-confidence "Uncertain" path.
