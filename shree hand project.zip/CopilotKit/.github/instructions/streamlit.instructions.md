---
applyTo: "app.py,pages/**/*.py"
---
- Cache the model with `@st.cache_resource` and data/JSON with `@st.cache_data`.
- Keep UI code thin: all ML logic is imported from `recognize.py` / `preprocess.py`.
- Use `st.session_state` for history and theme; handle "no hand detected" and missing-model states with friendly messages.
- Use `width="stretch"` (not `use_container_width`). Plotly for all charts. Layout must work on narrow screens (columns collapse).
- Every page must render without a camera (Simulator page covers this).
