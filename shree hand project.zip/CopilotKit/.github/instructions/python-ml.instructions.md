---
applyTo: "**/*.py"
---
- Prefer vectorised numpy/pandas over Python loops for landmark math (arrays shaped `(n, 21, 3)`).
- Landmark column order is `x0,y0,z0,x1,...,z20`; MediaPipe indices: 0 wrist, 1-4 thumb, 5-8 index, 9-12 middle,
  13-16 ring, 17-20 pinky.
- Normalise landmarks by translating the wrist to the origin and scaling by wrist->middle-MCP (index 9) distance.
- Save/load artifacts with joblib under `models/`; save metrics as JSON (convert numpy types first).
- Print short, readable progress logs in scripts; no bare `except:`.
