---
description: Step 6 - extra evaluation and robustness analysis
---
Follow `.github/copilot-instructions.md` and the spec in `docs/PROJECT_SPEC.md`.
First explain each file in 2-3 sentences, then create it. Work on THIS STEP ONLY.

## Goal
Create evaluate.py.
## Requirements
- Accuracy vs landmark noise sigma [0, .004, .01, .02, .03, .05]; accuracy vs roll range [0, 30, 60, 120, 180] degrees;
  most-confused gesture pairs on a hard setting. Save models/robustness.json.
## Acceptance check
`python evaluate.py` prints the sweeps. Then write 5 sentences interpreting the results honestly (what breaks first and why).

When finished: run the acceptance check, show the output, list the files you created, and stop. Do not start the next step.
