---
description: Step 2 - synthetic landmark dataset + generator
---
Follow `.github/copilot-instructions.md` and the spec in `docs/PROJECT_SPEC.md`.
First explain each file in 2-3 sentences, then create it. Work on THIS STEP ONLY.

## Goal
Build utils/synthetic_hand.py and datasets/generate_dataset.py.
## Requirements
- Parametric 3D hand: 5 fingers with extension in [0,1], joint-by-joint bending (MCP/PIP/DIP), thumb handled separately.
- 10 gestures with the finger flags from the spec; OK = thumb tip touches index tip.
- Per-sample randomisation: finger extension jitter, thumb angle, finger spread, 3D rotation (roll/pitch/yaw), scale,
  translation, left/right mirror, Gaussian noise (z noise 3x larger than x/y).
- Two difficulty presets: standard (training) and hard (held-out only). Function `sample_hand(gesture, rng, difficulty, handedness, overrides)`.
- generate_dataset.py writes datasets/landmarks_raw.csv (600/class, with ~1% NaN dropouts, ~0.5% duplicates, ~0.5% x8=3.0 outliers)
  and datasets/landmarks_hard_test.csv (150/class, clean). Add a docstring explaining the data is SIMULATED and how to swap in real data.
## Acceptance check
`python datasets/generate_dataset.py` prints ~6000 and 1500 rows with balanced classes.

When finished: run the acceptance check, show the output, list the files you created, and stop. Do not start the next step.
