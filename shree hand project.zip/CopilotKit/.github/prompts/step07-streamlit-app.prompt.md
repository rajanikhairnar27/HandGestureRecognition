---
description: Step 7 - Streamlit frontend
---
Follow `.github/copilot-instructions.md` and the spec in `docs/PROJECT_SPEC.md`.
First explain each file in 2-3 sentences, then create it. Work on THIS STEP ONLY.

## Goal
Create app.py.
## Requirements
- Sidebar navigation: Home, Recognize (st.camera_input + file upload, show landmarks drawn on image, label, confidence bar, top-3 chart, finger states, action),
  Simulator (choose gesture/hand/roll/pitch/yaw/noise; skeleton plot; prediction), Gesture Library, History (+CSV download).
- Dark/light theme toggle via CSS, responsive columns, friendly errors (no hand, missing model, MediaPipe unavailable). Dashboard page is built in step 8 (leave a placeholder).
## Acceptance check
`streamlit run app.py`; every page except Dashboard loads with no exceptions, and Simulator works without a camera.

When finished: run the acceptance check, show the output, list the files you created, and stop. Do not start the next step.
