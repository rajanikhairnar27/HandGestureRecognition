---
description: Step 11 - replace simulated data with REAL webcam data
---
Follow `.github/copilot-instructions.md` and the spec in `docs/PROJECT_SPEC.md`.
First explain each file in 2-3 sentences, then create it. Work on THIS STEP ONLY.

## Goal
Create collect_data.py (OpenCV webcam recorder using utils/landmarks.extract_landmarks).
## Requirements
- Keys 0-9 select the gesture; SPACE toggles recording; save one row per frame to datasets/landmarks_real.csv in the SAME schema
  (x0..z20, gesture, handedness, difficulty='real', ext_* flags). Show on-screen counts per gesture; target 300+ samples per gesture; support a --person name argument.
- Update preprocess.py/train_model.py to accept a flag (e.g. --data real) and split train/test BY PERSON when a 'person' column exists.
## Acceptance check
Record ~50 frames of two gestures, rerun preprocess + train with --data real, and show the new metrics.

When finished: run the acceptance check, show the output, list the files you created, and stop. Do not start the next step.
