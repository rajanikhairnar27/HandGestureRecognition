---
description: Step 5 - inference engine (recognizer)
---
Follow `.github/copilot-instructions.md` and the spec in `docs/PROJECT_SPEC.md`.
First explain each file in 2-3 sentences, then create it. Work on THIS STEP ONLY.

## Goal
Create recognize.py and utils/landmarks.py.
## Requirements
- GestureRecognizer.predict(landmarks) -> dict: gesture, raw_gesture, confidence, top3, fingers_extended (via thresholds), action, probabilities.
  confidence < 0.55 -> 'Uncertain'. explain() returns a readable sentence. GESTURE_ACTIONS mapping from the spec.
- utils/landmarks.py: extract_landmarks(rgb) using the MediaPipe **Tasks API** HandLandmarker (NOT mp.solutions); auto-download
  hand_landmarker.task to models/ on first use; draw_landmarks() with OpenCV; skeleton_figure() with Plotly; HAND_CONNECTIONS list.
## Acceptance check
Predict 1 fresh synthetic sample per gesture and print label, confidence and explanation (expect 10/10).

When finished: run the acceptance check, show the output, list the files you created, and stop. Do not start the next step.
