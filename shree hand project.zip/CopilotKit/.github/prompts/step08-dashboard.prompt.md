---
description: Step 8 - analytics dashboard
---
Follow `.github/copilot-instructions.md` and the spec in `docs/PROJECT_SPEC.md`.
First explain each file in 2-3 sentences, then create it. Work on THIS STEP ONLY.

## Goal
Add the Dashboard page to app.py using Plotly and models/metrics.json + robustness.json.
## Charts
Model comparison table + grouped bar (test F1 vs hard F1); latency vs hard-F1 scatter; confusion matrix heatmap (model selector);
per-gesture precision/recall/F1; class distribution; top-15 feature importance; PCA 2D scatter of features coloured by gesture;
noise and rotation robustness curves; most-confused table; session history chart.
## Acceptance check
Dashboard renders all charts with no exceptions.

When finished: run the acceptance check, show the output, list the files you created, and stop. Do not start the next step.
