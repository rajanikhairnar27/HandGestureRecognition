---
description: Step 9 - automated tests
---
Follow `.github/copilot-instructions.md` and the spec in `docs/PROJECT_SPEC.md`.
First explain each file in 2-3 sentences, then create it. Work on THIS STEP ONLY.

## Goal
Create tests/test_gesture.py.
## Cover
feature count == 36 and invariance (rotate/scale/shift/mirror); cleaning removes NaN/duplicate/outlier rows; every gesture recognised >= 90% on 20 fresh samples;
finger-state output for Open Palm; low-confidence path returns 'Uncertain'. Also add a Streamlit AppTest smoke test that loads each page.
## Acceptance check
`pytest -q` all green. If something fails, fix the code (not the test) unless the test is wrong, and explain.

When finished: run the acceptance check, show the output, list the files you created, and stop. Do not start the next step.
