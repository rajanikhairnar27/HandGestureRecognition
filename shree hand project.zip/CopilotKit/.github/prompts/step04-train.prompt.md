---
description: Step 4 - train and compare models
---
Follow `.github/copilot-instructions.md` and the spec in `docs/PROJECT_SPEC.md`.
First explain each file in 2-3 sentences, then create it. Work on THIS STEP ONLY.

## Goal
Create train_model.py.
## Requirements
- 6 models each in Pipeline(StandardScaler, clf): LogReg, KNN(7), DecisionTree, RandomForest (GridSearchCV), SVC-RBF probability=True (GridSearchCV), MLP(64,32).
- Stratified 80/20 split; metrics per model: accuracy, macro precision/recall/F1, confusion matrix, classification_report dict,
  5-fold CV F1 mean/std, hard-set accuracy/F1, train time, single-frame predict_proba latency (ms).
- Choose best by 0.5*test F1 + 0.5*hard F1. Save models/gesture_model.joblib, models/metrics.json (incl. feature importances from RF),
  models/finger_thresholds.json (midpoint of curl_ratio class means per finger).
## Acceptance check
`python train_model.py` prints a comparison table and the best model name. Explain in 3 lines why hard-set F1 differs from test F1.

When finished: run the acceptance check, show the output, list the files you created, and stop. Do not start the next step.
