---
description: Step 1 - project folder structure and base files
---
Follow `.github/copilot-instructions.md` and the spec in `docs/PROJECT_SPEC.md`.
First explain each file in 2-3 sentences, then create it. Work on THIS STEP ONLY.

## Goal
Create the project skeleton.
## Do
- Folders: datasets/, models/, utils/ (with __init__.py), notebooks/, tests/, .streamlit/
- Empty-but-documented placeholders for preprocess.py, train_model.py, recognize.py, evaluate.py, app.py
- requirements.txt (numpy, pandas, scikit-learn, joblib, streamlit>=1.50, plotly, pillow, opencv-python-headless, mediapipe, pytest)
- .gitignore (venv, __pycache__, .pytest_cache, models/*.task), README.md skeleton, .streamlit/config.toml (green theme)
## Acceptance check
`pip install -r requirements.txt` succeeds and the tree matches the layout in copilot-instructions.md.

When finished: run the acceptance check, show the output, list the files you created, and stop. Do not start the next step.
