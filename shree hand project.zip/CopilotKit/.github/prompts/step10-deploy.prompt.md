---
description: Step 10 - deployment and documentation
---
Follow `.github/copilot-instructions.md` and the spec in `docs/PROJECT_SPEC.md`.
First explain each file in 2-3 sentences, then create it. Work on THIS STEP ONLY.

## Goal
Prepare deployment + docs.
## Do
- Dockerfile (python:3.11-slim, apt libgl1 libglib2.0-0, install requirements, run the 4 pipeline scripts at build, expose 8501).
- packages.txt for Streamlit Community Cloud, final README (setup, pipeline table, run commands, deploy steps, honest limitations section).
## Acceptance check
`docker build` succeeds (or explain how to verify) and README commands run in order on a clean clone.

When finished: run the acceptance check, show the output, list the files you created, and stop. Do not start the next step.
