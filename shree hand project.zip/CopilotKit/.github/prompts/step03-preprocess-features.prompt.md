---
description: Step 3 - cleaning, normalisation, feature engineering
---
Follow `.github/copilot-instructions.md` and the spec in `docs/PROJECT_SPEC.md`.
First explain each file in 2-3 sentences, then create it. Work on THIS STEP ONLY.

## Goal
Create preprocess.py.
## Requirements
- clean_raw(): drop duplicates, NaN rows, out-of-frame outliers (x/y outside -0.5..1.5); return a cleaning report dict.
- normalize_landmarks(), engineer_features((n,21,3) -> DataFrame of the 36 features in the spec), FEATURE_NAMES, build_feature_table(), run_pipeline()
  -> datasets/features.csv, features_hard_test.csv, models/label_encoder.joblib, models/cleaning_report.json.
- engineer_features must be reused later by inference (single source of truth). Do NOT scale here (scaling goes in the model Pipeline).
## Acceptance check
Run `python preprocess.py`. Then show that features are identical (diff < 1e-6) after rotating, scaling, shifting and mirroring one sample.

When finished: run the acceptance check, show the output, list the files you created, and stop. Do not start the next step.
