# Project: Hand Gesture Recognition System (final-year ML project)

Recognize 10 hand gestures (Fist, Open Palm, Thumbs Up, Peace, Point, Rock, Three, Four, Call Me, OK)
from MediaPipe hand landmarks (21 points x xyz), classify with scikit-learn, map to actions, and serve
through a Streamlit app with an analytics dashboard. Full requirements: `docs/PROJECT_SPEC.md`.

## Stack
Python 3.11, numpy, pandas, scikit-learn, joblib, MediaPipe (**Tasks API**), opencv-python-headless,
Streamlit >= 1.50, Plotly, pytest.

## Project layout (keep exactly)
- `datasets/` CSVs + `generate_dataset.py` | `models/` saved artifacts + `metrics.json`
- `utils/` `synthetic_hand.py`, `landmarks.py` | `tests/` pytest
- Root: `preprocess.py`, `train_model.py`, `recognize.py`, `evaluate.py`, `app.py`, `realtime_webcam.py`,
  `requirements.txt`, `README.md`, `Dockerfile`

## How to work
- Do ONE pipeline step at a time (see `.github/prompts/`). Never start the next step unprompted.
- Before creating each file, explain in 2-3 sentences what it does and why.
- After code changes, run the relevant command/test and show the result; fix failures before moving on.
- Update `requirements.txt` whenever you add an import. Never add a dependency without saying why.

## Code conventions
- Type hints + short docstrings; small single-purpose functions; comments explain *why*.
- Build paths with `pathlib.Path(__file__).resolve().parent`; no absolute or cwd-dependent paths.
- Seeds fixed to 42 (`random_state=42`, `np.random.default_rng(42)`).
- No logic in notebooks; notebooks only import from the modules.

## ML rules (important for academic marking)
- Split train/test BEFORE any fitting. Scaling lives inside `Pipeline([StandardScaler, model])`.
- ONE shared `engineer_features()` used by training AND inference (no train/serve skew).
- Features must be rotation/scale/position/mirror invariant (distances and angles only).
- Report macro precision/recall/F1, confusion matrix, 5-fold CV, and a separate harder held-out set.
- Never claim synthetic-data accuracy is real-world accuracy; say so in README and dashboard.

## Version pitfalls — avoid these (common in older examples)
- Do NOT use `mp.solutions.hands` (removed in newer MediaPipe). Use `mediapipe.tasks.python.vision.HandLandmarker`
  with the `hand_landmarker.task` model (auto-download to `models/`), RGB input via `mp.Image`.
- Do NOT pass `multi_class=` to `LogisticRegression` (removed in recent scikit-learn).
- Streamlit: use `width="stretch"` instead of `use_container_width=True`.
- Pandas: no `inplace=True` chained assignment; use `.loc`.

## Commands
```
python datasets/generate_dataset.py && python preprocess.py && python train_model.py && python evaluate.py
pytest -q
streamlit run app.py
```
