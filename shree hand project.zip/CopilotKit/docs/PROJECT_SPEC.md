# Hand Gesture Recognition System — Specification

## Academic requirements
Real-world ML problem; data collection + preprocessing; model training/testing/evaluation; predictive analytics;
charts + dashboard; deployed modern web app.

## Gestures and actions
Fist=Mute, Open Palm=Pause/Stop, Thumbs Up=Like/Confirm, Peace=Screenshot, Point=Select/Click, Rock=Play music,
Three=Workspace 3, Four=Open menu, Call Me=Start call, OK=Accept.
Finger flags [thumb,index,middle,ring,pinky]: Fist 00000, Open Palm 11111, Thumbs Up 10000, Peace 01100, Point 01000,
Rock 01001, Three 01110, Four 01111, Call Me 10001, OK 00111 (thumb tip touches index tip).

## Data
Schema: `x0,y0,z0 ... x20,y20,z20, gesture, handedness, difficulty, ext_thumb..ext_pinky`.
Training pool (~600/gesture) + separate HARD held-out set (more rotation + sensor noise).
Start with simulated landmarks (parametric 3D hand model), then REPLACE with real webcam data (step 11).
Inject/handle: duplicates, NaN dropouts, out-of-frame outliers.

## Preprocessing + features (36, all invariant to rotation/scale/position/handedness)
Normalise (wrist-centred, palm-scaled). Features: tip-to-wrist distances (5), curl ratios (5), joint angles (10),
fingertip-to-fingertip distances (7), tip-to-palm-centre distances (5), thumb-tip-to-index-MCP (1),
thumb-vs-hand-axis cosine (1), finger spread angles (2).

## Models and evaluation
Logistic Regression, KNN, Decision Tree, Random Forest (tuned), SVM-RBF (tuned), MLP — each in
`Pipeline(StandardScaler, model)`. Metrics: accuracy, macro precision/recall/F1, confusion matrix, 5-fold CV F1,
hard-set F1, single-frame latency (ms). Best model = mean of test F1 and hard-set F1.
Robustness sweeps: accuracy vs landmark noise, accuracy vs rotation; most-confused pairs.

## Recognizer
Output: gesture, confidence, top-3, per-finger extended/curled (explainability), mapped action;
confidence < 0.55 -> "Uncertain".

## App (Streamlit)
Home, Recognize (webcam snapshot + upload), Simulator (no camera needed), Dashboard (model comparison, confusion
matrix, per-class scores, feature importance, PCA scatter, robustness curves, latency trade-off), Gesture Library,
History (+ CSV download), dark/light theme, responsive. Extra: `realtime_webcam.py` with majority-vote smoothing.

## Deployment
Streamlit Community Cloud (`packages.txt`: libgl1, libglib2.0-0) and Docker.
