# Building the Hand Gesture Recognition System with GitHub Copilot

## 0. One-time setup
1. VS Code + the **GitHub Copilot** and **Copilot Chat** extensions; sign in.
2. Create an empty repo folder, `git init`, copy this kit into it (`.github/`, `docs/`, this file).
3. Create a venv: `python -m venv .venv`, activate it. Python 3.11 recommended.
4. Open Copilot Chat, switch the mode dropdown to **Agent** (it can create files and run terminal commands, asking your approval).
5. Check that instructions are loaded: after any reply, expand the "References" list; `copilot-instructions.md` should appear.
   (If prompt files don't appear when you type `/`, update VS Code and confirm they live in `.github/prompts/`.)

## 1. The loop (repeat for each step)
1. **New chat** per step (keeps context clean).
2. Type `/step01-structure` (the filename without `.prompt.md`) and send. Optionally add context with `#file:docs/PROJECT_SPEC.md`.
3. Read Copilot's plan and each file explanation. Review the diff before accepting. Approve terminal commands you understand.
4. Run the step's **acceptance check** yourself, don't trust "it works".
5. If something fails, paste the full traceback into the same chat: "Fix this; explain the root cause in 2 lines."
6. `git add -A && git commit -m "stepNN: <what>"`. One commit per step gives you a clean history for your viva.

| Step | Prompt | You should see |
|---|---|---|
| 1 | `/step01-structure` | skeleton + requirements install |
| 2 | `/step02-dataset` | ~6000 + 1500 rows, balanced classes |
| 3 | `/step03-preprocess-features` | cleaning report, 36 features, invariance proof |
| 4 | `/step04-train` | 6-model comparison table, best model saved |
| 5 | `/step05-recognizer` | 10/10 gestures recognised with explanations |
| 6 | `/step06-evaluate` | noise/rotation sweeps + honest interpretation |
| 7 | `/step07-streamlit-app` | app runs, Simulator works without camera |
| 8 | `/step08-dashboard` | all charts render |
| 9 | `/step09-tests` | `pytest -q` green |
| 10 | `/step10-deploy` | Dockerfile, packages.txt, final README |
| 11 | `/step11-real-data` | your own webcam data + retrained metrics |

## 2. Where Copilot usually goes wrong (check these)
- **MediaPipe**: it often writes `mp.solutions.hands` from older tutorials. Newer releases removed it; the instructions say to use the Tasks API. If it slips, say: "Use the MediaPipe Tasks HandLandmarker API, not mp.solutions."
- **Data leakage**: if you see `StandardScaler().fit_transform(X)` before `train_test_split`, reject it. Scaler belongs in the Pipeline.
- **Train/serve skew**: inference must call the same `engineer_features` as training. Reject duplicated feature code.
- **Hard-coded numbers**: it may paste fake metrics into the README/dashboard. All numbers must come from `models/metrics.json`.
- **Old APIs**: `multi_class=` in LogisticRegression, `use_container_width=True` in Streamlit, `inplace=True`.
- **Scope creep**: if it starts the next step, reply "Stop. Only this step."

## 3. Useful follow-up prompts
- `Explain models/metrics.json fields as if I'm presenting to my examiner.`
- `Review train_model.py for data leakage and reproducibility problems. List issues, don't change code yet.`
- `#codebase Find any code path where training and inference compute features differently.`
- `Generate viva questions and answers about this project's ML pipeline.`
- `Write the "Limitations" section of the README honestly given the data is simulated (until step 11 is done).`

## 4. Be honest in your report
Simulated data gives near-100% standard-test scores. Do step 11, collect real data from several people, split by person,
and report *those* numbers. Examiners value an honest drop (e.g. 100% -> 90%) with analysis far more than a suspicious 100%.

## 5. Optional: use the finished reference build
`HandGesture.zip` (from the previous message) is a complete working version. Put it in a `reference/` folder and ask
Copilot to compare its output with it using `#folder:reference`, but write your own code so you can explain it.
